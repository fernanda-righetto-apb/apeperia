const form = document.querySelector("#form");
const nameInput = document.querySelector("#name");
const emailInput = document.querySelector("#email");
const passwordInput = document.querySelector("#password");
const jobSelect = document.querySelector("#job");
const messageTexarea = document.querySelector("#message");


//imprimindo no console os elementos da DOM (Document Object Model)

// console.log(form, nameInput, emailInput);

console.log(typeof messageTexarea);

form.addEventListener('submit', (event) => {
    event.preventDefault();

    //verificar se o nome está vazio
    if(nameInput.value === ""){
        alert("Por favor, preencha seu nome");
        return;
    }

    //verifica se o email está preenchido
    if(emailInput.value === "" || !isEmailValid(emailInput.value)){
        alert("Por favor, preencha seu e-mail");
        return;
    }

    //verifica se a senha foi preenchida e se tem pelo menos 8 caracteres / se não passar, exibe o alerta
    if(!validatePassword(passwordInput.value,8)){
        alert("A senha precisa ter no mínimo 8 dígitos")
    }

    //verifica se a situação foi escolhida
    if(jobSelect.value === ""){
        alert("Por favor, selecione sua opção");
    }

    //verifica se a mensagem foi preenchida
    if(messageTexarea.value === ""){
        alert("Por favor, escreva uma mensagem");
    }


    //se todos os campos estão preenchidos corretamente, envia o form
    form.submit();

})

function isEmailValid(email){
    //criar um regex (verificação de formato) para validar email
    const emailRegex = new RegExp(
        //usuario12@host.com.br
        /^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}$/
    );

    if(emailRegex.test(email)){
        return true;
    }
    return false
}

//valida a senha
function validatePassword(password, minDigits){
    if(password.length>=minDigits){
        //senha válida
        return true;
    } 
    return false;
}